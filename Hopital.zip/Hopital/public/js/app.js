// Fichier JS pour la gestion des formulaires ou des événements
console.log("App JS loaded");